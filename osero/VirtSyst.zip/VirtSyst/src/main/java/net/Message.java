package net;

public class Message {
    String message;
    String ipAddress;
    String port;
}
