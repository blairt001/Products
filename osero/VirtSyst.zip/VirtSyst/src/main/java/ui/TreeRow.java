package ui;

import java.io.File;

public class TreeRow {
    private File file;

}
